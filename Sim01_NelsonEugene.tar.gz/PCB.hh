#ifndef pcb_hh
#define pcb_hh

class PCB
{
	public:
		int processState;
};

#endif